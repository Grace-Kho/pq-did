LIGETRON-DOMAIN-MASK-CORRECTION-1: external component review handover

This archive contains exactly the 15 requested existing files plus this guide
and MANIFEST.json. Original payload bytes and project-relative paths are preserved.
MANIFEST.json records original absolute paths, archive paths, lengths and SHA-256.
Its README checksum covers this guide; the externally reported ZIP checksum covers
MANIFEST.json too. No archived code was executed during packaging.

Suggested reading order
1. docs/ligetron_domain_mask_correction.md: identities, exact component contract,
   theorem correspondence, validation layers, failures and limitations.
2. docs/data/ligetron_domain_mask_correction_1/component-contract.json and
   references.json: algebraic premises and retained reference identities.
3. The two reviewed-overlay.patch files, in the application order below, then
   build-input-seal.json. Read case-driver-amendment.json alongside cases.py:
   only selection of successful build 2 changed; expectations were unchanged.
4. native.cpp, overlay/include/zkp/pqdid_domain_mask_exp1.hpp, expectations.py,
   expectations.json and expectation-seal.json. Paths start with experiments/
   ligetron_domain_mask_correction_1 or docs/data/ligetron_domain_mask_correction_1.
5. outcomes.json and validation-closure.json: 32 cases passed once; preservation
   closure is complete. The individual case files linked by outcomes.json are
   outside the explicitly requested 15-file handover and are not included.

Patch application order (reference information, not execution authorisation)
Base: public Ligetron commit 4b1cdef1bfdf4497fb3e38170db4541fba3f6c12;
recorded tree: 95984ef209bf37a53624d27a36905e41886dacfc.
First: docs/data/ligetron_correction_admission_1/reviewed-overlay.patch
SHA-256: 043ee96fbae51b9416b3435be7e7ad27cfc076ddb7790e14f14be6ea09c0dc3c
Second: docs/data/ligetron_domain_mask_correction_1/reviewed-overlay.patch
SHA-256: 31f1515e498182664f51e92d91925416c0063d5b117494948e4a52dc6fcc5723
The second patch is incremental over the preceding overlay, using pinned sources
for files not changed by that overlay. The complete source/dependency checkout,
binaries, build logs and referenced PDFs are not included. Patch application or
build reproducibility was not revalidated by this packaging operation.

Recorded scope
Component-only experimental overlay: BN254 scalar field, k=8192, ell=7936,
n=32768, 192 queries, 256 padding coordinates, code domain 7 H_n. Row degree <k;
linear/quadratic degree <2k-1. Actual CPU field/RNG/witness-manager components and
labelled CPU transform models were checked. Small transform/mask cases use
k=8, ell=4, n=32. GPU paths, full-sized masks, VM and complete prover/verifier
execution remain unrun. Finite checks do not prove complete-view privacy.

Complete-proof admission remains denied. Modified degree/theorem correspondence,
joint commitment simulation, public challenge expansion, compiler binding,
same-assignment extraction, quantum/Fiat-Shamir and finite-parameter obligations
remain open. The report contains the precise limitations; no new analysis is
introduced by this guide. Reference PDFs were inspected online in the recorded
work; no retained PDF hashes are available.

The implementation package remains closed. Baselines and historical evidence are
unchanged. Only manuscript Sections II-VIII and agreed clarifications are
authoritative. Private verification is fail-closed, proving/isolation paused,
and the proof ledger remains two used and one unused. No new package is approved.
