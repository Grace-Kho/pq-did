LIGETRON dependency/hardware preflight and inactive engineering proposal

Start with docs/data/ligetron_dependency_hardware_preflight_1/PROPOSAL.md, then
RUNBOOK.md, dependency-lock.proposed.json, package-closure.json, hardware.json,
hardware-host.json, ledger.json and resource-closure.json in that same directory.
The full archive SHA-256 is supplied in the chat and external archive-result.json;
a ZIP cannot contain its own final cryptographic digest.

Incoming external review: incoming_review/REVIEW.md and CODEX_PROMPT.txt. The latest
user instruction separates engineering feasibility from cryptographic admission.
The original received ZIP is also included unchanged; its embedded return ZIP
matches our earlier handover. Reconciliation charges its63229 bytes only once.

Patch order: pinned Ligero4b1cdef1bfdf4497fb3e38170db4541fba3f6c12, randomness
overlay under docs/data/ligetron_correction_admission_1, then domain/mask overlay
under docs/data/ligetron_domain_mask_correction_1. Both patch hashes are preserved.
No proposed third integration overlay has yet been implemented.

Prior reports, component contract/references, original/overlaid source snapshots,
harnesses/expectations, all35+32 individual outcome records and closures are
included for review, not execution. No binaries or whole build directories.
MANIFEST.json records every payload's original location, size and SHA-256;
README is indexed, while MANIFEST intentionally does not hash itself.

Missing/unestablished evidence: complete new Dawn/WABT checkouts and package
payloads; native build compatibility; usable Dawn adapter; GPU/shader/full-VM
execution; corrected statement/parser third overlay; full-sized complete-path
resource measurement; exact updated primary theorem/Appendix C; complete degree,
masking, commitment/compiler, public-expansion, extraction and quantum arguments.
Existing Python/CPU component success establishes none of those native/security
claims. The known67 outcomes were reused, not rerun.

No private-proof admission, manuscript/profile change or resource amendment is
activated. KYC302 historical observations/four smoke observations remain preserved;
their datasets are not duplicated into this backend review. No complete historic
preservation audit was repeated. Private verification remains fail-closed,
proving/isolation paused, proof ledger2 used/1 unused. Do not execute archived code.
