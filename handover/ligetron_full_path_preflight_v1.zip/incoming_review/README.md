# Ligetron domain/mask review and next Codex task

Read `REVIEW.md`, then use `CODEX_PROMPT.txt` as the next message to the Codex instance in `/home/grace/projects/pq-did`.

This is an external review of the uploaded handover. It does not modify the WSL project or authorise builds, tests, GPU execution, proofs, installations, or changed resource limits. The prompt requests one consolidated, read-only admission decision and prospective execution amendment.

`verification.json` records archive checks, patch reconstruction, and independent arithmetic checks performed for this review. Those checks are not a rerun of the 32 native/model cases. `MANIFEST.json` records this response package's file hashes.

The original upload and its failures, measurements, patches and completion scope remain unchanged. Future Codex review handovers should contain all required material in one verified ZIP.
