# Review of LIGETRON-DOMAIN-MASK-CORRECTION-1

Date: 3 October 2026.

## Decision

Retain this as a completed component package. Its patch chain and supplied evidence are internally consistent with the stated CPU-native/CPU-model scope. This review did not establish a new defect in the inspected mask formulas, coset constants, or decode/degree-check ordering. Complete backend correctness, private authentication, and overall post-quantum security remain unestablished.

Do not restart the baseline, replace ML-DSA, or reopen Binius. The next decision concerns this exact Ligetron overlay: whether its complete implemented protocol can be justified and whether one bounded full-path experiment is worth admitting. A model-only pass cannot resolve those questions.

## What was independently checked

- Uploaded ZIP: 56,093 bytes; SHA-256 `cbdf039e61556e945da980f9cb1f210da933ff1f3185203528f43279edb7493b`; 17 members. Safe member paths, compression integrity and all supplied payload hashes passed.
- Both patches apply without fuzz to retained sources for commit `4b1cdef1bfdf4497fb3e38170db4541fba3f6c12`.
- All 11 reconstructed overlay files match `build-input-seal.json`. The driver has a separately recorded build-selection amendment; it must not be compared indiscriminately with its pre-amendment hash.
- The shader constants equal `7R mod p` and `7^-1 R mod p`, with `R=2^256 mod p`. Also `7^32768 != 1 mod p`.
- The reported closure declares 32 fixed cases passed and full GPU/VM/prover/verifier execution unrun. The detailed per-case files and binaries are not in this upload; this review inspected the harness, frozen expectations, driver and outcome index and did not reproduce execution.

No uploaded executable or test program was run. Temporary patch reconstruction and simple reviewer-written integer calculations occurred only in the review workspace, not Grace's WSL project. Its preservation audit was not independently repeated.

## Algebra and implementation assessment

1. **Disjoint domains:** the selected coset separates message nodes from code queries. Forward coefficient scaling and inverse scaling have the correct signs. The engine inserts inverse scaling before folding.
2. **Code mask:** drawing all k coordinates removes the previous zero-tail cancellation premise. This is an algebraic repair under independent, uniform successful draws, not a whole-transcript privacy result.
3. **Linear mask:** sampling degree `<2k-1` coefficients then subtracting the mean of the selected message-node evaluations is a surjective projection onto the sum-zero subspace. It preserves the degree bound.
4. **Quadratic mask:** fixing the required message-node zeros and solving one remaining evaluation to remove the top inverse-transform coefficient gives the claimed constrained parameterisation. The generator orientation agrees with the even-indexed message nodes.
5. **Degree-check ordering:** `decode_ntt_device` folds and transforms the first k entries but retains the coefficient tail. Thus checking indices `>=2k-1` after this operation is not, by itself, the suspected representation error. Code-degree checking starts at k. This source reasoning still needs actual device validation.
6. **GPU patch breadth:** regenerating the packed shader changes considerably more text than the added coset kernels. That is not evidence of an error, but the generated file/template identity and actual shader compilation must be tested together. CPU transforms do not validate the GPU arithmetic or dispatch sequence.

## A useful conditional joint-view argument

There is a more focused route than treating each mask independently. Consider only the algebraic oracle model with honest verifier challenges and query positions sampled independently of the private coins, not hash-derived from commitments. Fix those challenges and a valid assignment. Let W denote the padded row polynomials. Write the three responses as:

`C = R_code + G_code(W)`

`L = R_linear + G_linear(W)`

`Q = R_quad + G_quad(W)`.

If the three masks are independent and uniform in their stated polynomial spaces, each response is uniform in the corresponding space or public affine coset, independently of W. For L the affine condition is its public required sum; for Q it is vanishing on the required message nodes. The degree bounds must contain the respective G polynomials.

If additionally each distinct private row has independent uniform padding, the same at-most-192 distinct query positions lie in the disjoint code domain, and no other observations occur, the padding evaluation map has full row rank. One can sample the responses, sample the queried row symbols with their required alias relationships, and compute queried mask symbols by subtracting the relevant G values. Translation by independent uniform masks explains the joint response distribution.

This is a conditional argument for the algebraic oracle view. Its premises have NOT been established for every native batched path. Shared buffers, duplicated rows and derived rows must be represented consistently; they cannot all be declared independent. It does not simulate early Merkle roots, authentication paths or hash-derived challenges, and supplies no extractor. It is a concrete starting point for the remaining correspondence, not a backend-admission theorem.

## Remaining decisions that matter

### Linear degree and exact reference version

The implementation's public coefficient rows have degree `<k`; the cited analysis uses `<ell`. The implemented linear response bound is therefore `<2k-1`, rather than `<k+ell-1`. This can be a sensible extension, but its soundness, simulation and extraction correspondence must be written explicitly or the coefficient encoding must be changed in a specified way. Increasing the mask degree alone is not that argument.

The inspected 47-page extended Ligero paper has Lemma 4.15, Theorem 4.7 and the separate compilation in Section 5. The inspected Frigo–shelat paper quotes an updated result and an Appendix C improvement not present in that 47-page copy. Pin the exact primary theorem version used; do not silently mix them. Sources:

- https://eprint.iacr.org/2022/1608.pdf
- https://eprint.iacr.org/2024/2010.pdf

Keep classical oracle privacy, knowledge extraction, Fiat–Shamir/QROM results, concrete hash assumptions and finite losses separate. A 192-query setting or 254-bit field alone establishes no overall security number. This review does not infer insecurity from a loose or inapplicable upper bound.

### Actual protocol and transcript

The source-only batch changes adjust padding length, while the P-cases use models rather than complete ordinary/batched callbacks. Three-stage replay is also not a complete prover execution. Finish the ordered oracle/row/mask/response/query inventory and show which paths satisfy the conditional argument above.

The new Stage1 profile tag and feeding the Stage1 digest into Stage2 improve explicit binding. They do not finish statement binding: the inspected prover computes a program hash for metadata, but that hash is not an explicit input of the Stage1 helper; the instance loop hashes public values without explicitly including argument indices and the private/public layout. Determine the exact fixed-program assumption or specify complete canonical statement binding. This is a correspondence obligation, not a demonstrated substitution attack.

Public-seed challenge expansion, actual commitment construction, parser/serialization boundaries and same-assignment extraction remain necessary. Do not treat a secret-key PRG argument as a justification for arbitrary publicly seeded challenges.

### Execution and resources

The next execution should exercise the actual shader and callbacks, then a tiny complete synthetic program only if separately admitted. It should not start with hidden-message ML-DSA. No complete proving resource estimate follows from these 32 cases.

The latest supplied report says builds are 13/13 consumed and this component has only 1,832 bytes of evidence headroom. Unused invocations include reserved corrective slots. Live balances may differ after packaging. Any new execution needs one consolidated prospective amendment; do not reuse reserved slots or reset consumption. GPU/WSL availability must be checked before promising a device run.

## Practical next outcome

Use the enclosed prompt to obtain one concrete protocol-admission decision, the exact corrections if needed, and one complete execution/resource proposal. It must either identify an applicable construction and testable full path, or state the precise remaining mathematical obstacle. It must not produce another backend survey or count component success as private authentication.

The genuine ML-DSA baseline, 302 historical observations and four smoke observations remain usable. Complete PQ-DAA authentication, standards conformance and full private-proof benchmarking remain unfinished. The 31 October 2026 goal is unchanged, but this evidence does not support a full-completion promise.
