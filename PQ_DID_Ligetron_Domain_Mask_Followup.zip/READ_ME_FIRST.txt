PQ-DID: Ligetron domain and code-test mask follow-up
Prepared 1 October 2026. Status: source/algebra findings for independent review.

The completed LIGETRON-CORRECTION-AND-ADMISSION-1 remains valid within its
reported CPU randomness-component scope. Its 35 native cases do not test the
issues below. This handover does not reopen that package or change WSL ledgers.
The final reviewed overlay (SHA-256
043ee96fbae51b9416b3435be7e7ad27cfc076ddb7790e14f14be6ea09c0dc3c)
was reported by the user; its bytes have not been inspected in this workspace.
Codex must check whether it changes any of the paths or assumptions below.

Pinned public commit: 4b1cdef1bfdf4497fb3e38170db4541fba3f6c12.
Root tree: 95984ef209bf37a53624d27a36905e41886dacfc.
Twelve unmodified upstream files are included and mapped to the GitHub API
commit/tree records. Length and computed Git blob checks passed for every file.
This is not a full checkout, native build or git-fsck result.

1. Domain overlap: changing a root generator does not separate these domains

src/bn254.cpp::generate_omegas derives omega_k from root1 and omega_n from
root2. Exact arithmetic gives root1*root2 = 1 mod p and omega_n^4 = omega_k^-1
for the defaults k=8192,n=32768. Consequently

    omega_n^((-4*i) mod n) = omega_k^i.

Thus every one of the k interpolation nodes is in the n-point evaluation
domain, and 8,000 of them correspond to the default message positions.
The comment that choosing a different high-exponent generator prevents
information leakage does not establish domain separation: generators of a
fixed finite-field subgroup enumerate the same subgroup.

src/webgpu/engine.cpp::encode_ntt_device executes inverse-k NTT followed by
forward-n NTT. Its forward kernel supplies natural-order output after bit
reversal; shader/kernels.wgsl.in implements the ordinary butterflies. No coset
coefficient scaling was identified on this path. Under those encoder semantics,
the codeword at index (-4*i) mod n equals the original row value at position i.

webgpu_prover.cpp samples from all n positions, not a domain excluding those
indices. nonbatch_stage3_context samples original encoded rows into
host_samplings; proof_serializer.hpp serialises that vector. The corresponding
gather kernel copies the selected field elements. Authentication by Merkle
paths does not conceal their contents.

Implication requiring native confirmation: a sampled overlapping message
position can reveal that row's data value. Which such values are secret in a
particular application must be traced; this is not a measured disclosure of a
PQ-DID credential. For ideal uniform sampling, 192*8000/32768=46.875 message
positions is an expectation per selected column set, not an observed count,
not a count of distinct secrets, and not a security bound for the actual RNG.

2. Zero-tail code-test mask: a separate algebraic disclosure

witness_manager::process_masks creates a code mask with ell random elements
then k-ell public zeros. nonbatch_stage2_context::mask_callback adds its encoded
row to the code-test response with coefficient one. check_code uses public
row weights. webgpu_prover.cpp serialises the complete encoded response and
the later row samples. These are different disclosures from roots alone.

Let E be the injective linear row encoder, with a public left inverse on its
image. Write row inputs u_i=(w_i,rho_i), the code mask a=(s,0), and public
weights r_i. If the public response is

    C = E(a) + sum_i r_i E(u_i),

then the padding coordinates of c=E^-1(C) are sum_i r_i rho_i. At any queried
position j whose original row values U_i[j]=E(u_i)[j] are disclosed, compute

    Z_j = sum_i r_i U_i[j] - E(0,c_pad)[j]
        = E(sum_i r_i w_i,0)[j].

This is a witness-dependent linear statistic when the last functional is
nonconstant on the relation's possible witnesses. It needs neither all private
rows nor all their encoded vectors: the full public code-test response and
the actually opened column are sufficient under the displayed premises.
For an application-level distinguisher, the relevant row weights, layout and
two satisfying assignments for the same public statement still must be mapped.

The included GF(97) calculation uses k=4,ell=2,t=1 and a disjoint evaluation
coset. Both the strict k>ell+t inequality and disjointness hold. A one-row model
with message (b,0), b in {0,1}, recovers b for both values from that view.
Therefore neither simply subtracting one from ell nor fixing domain overlap
alone removes this second algebraic problem.

This is a source-supported algebraic counterexample to the specified local
masking view, not an executed GPU prover attack or a full Fiat-Shamir security
analysis. Roots may affect challenge selection; the relation of the fixed
model challenge to native hash-derived challenges remains to be checked.

3. Concrete correction candidates, not an admitted full repair

A. Use an evaluation domain disjoint from the interpolation/message domain.
For multiplicative subgroups, one candidate is delta*H_n with delta^n != 1.
Encode by scaling coefficient j by delta^j before the forward-n transform;
decoding reverses this factor before the existing message-domain evaluation.
Every ordinary, batch and degree-2k mask path must use the same defined domain.
This is not achieved by merely choosing another primitive n-th root, nor by
silently dropping query positions (which changes sampling/soundness accounting).

B. For the affine code-test variant, assess a code mask uniformly distributed
over the full k-dimensional code, rather than zeroing its padding coordinates.
In source this would change the code-mask draw from ell elements plus zeros
to k random elements. Replay/random-consumption order, mask commitments, all
three prover stages and verifier assumptions require matching validation.
The finite model shows only that uniform extra mask coordinates hide the
specific statistic Z_j; it does not prove complete-view zero knowledge.

C. Independently settle the query budget and padding/degree conditions.
Do not silently reduce the 192 queries. Keep k-ell distinct from query count
in all row/batch paths, and account for extra entropy required by the selected
commitment/compiler. The full linear and quadratic mask laws also need mapping.

These are conventional coding/masking directions. They are not a claim that
the selected complete Ligetron protocol is thereby covered by an existing
knowledge/privacy theorem. Commitment hiding, full transcript binding, public
challenge expansion, same-assignment extraction, quantum/Fiat-Shamir and finite
parameter obligations remain explicit. No complete ML-DSA pilot is admitted.

4. Exact source anchors

- src/bn254.cpp: root1/root2 and generate_omegas.
- src/webgpu/engine.cpp: encode_ntt_device, decode_ntt_device,
  ntt_forward_kernel, ntt_inverse_kernel, ntt_precompute_omegas, sample_gather.
- shader/kernels.wgsl.in and pack/shader/bignum.wgsl: forward/inverse NTT,
  bit reversal, sample_gather. Actual selected shader must match before any
  future native GPU claim.
- include/zkp/backend/witness_manager.hpp: process_reset_linear_row,
  process_reset_quadratic_rows, process_masks.
- include/zkp/nonbatch_context.hpp: nonbatch_stage1/2/3_context callbacks,
  stage2 check_code and stage3 sample_row/host_samplings.
- src/webgpu_prover.cpp: stage2 encoded response, all-n index sampling and
  serialisation; src/webgpu_verifier.cpp: corresponding response/sampling use.
- include/zkp/proof_serializer.hpp: encoded_code and sampled_data fields.

5. References and scope of claims

Ligero extended paper https://eprint.iacr.org/2022/1608.pdf:
Sections 4.6.1 and B.3 describe code-test blinding/affine variants; Lemma 4.15
states a strict masking/query condition; Section 5 separately treats the
commitment and noninteractive transformations. These references motivate the
correction directions; no complete theorem-to-release correspondence is claimed.

The two findings use the explicit linear algebra above and pinned source,
not a claim that a concrete hash is literally a random oracle. No external
messages were sent. No WSL source, manuscript, baseline dataset, resource cap,
test/build counter or proof ledger was changed. No native proof, GPU execution,
ML-DSA test or production attack was run here.

6. Next decision

Independently verify or refute both findings against the retained final overlay,
then give one integrated domain/masking/profile correction proposal with exact
native correspondence checks and a complete resource amendment if necessary.
Do not split these into successive one-defect approval loops. If the complete
profile still requires an unavailable construction theorem, state that terminal
gate rather than treating the component fixes as proof admission.
