"""Finite-field calculations only. Not a native Ligetron proof or attack."""
import json


def domain_calculation():
    p = 21888242871839275222246405745257275088548364400416034343698204186575808495617
    r1 = 1748695177688661943023146337482803886740723238769601073607632802312037301404
    r2 = 2037444462055058054189478067370099086220733342011840546702672064072905551290
    k, ell, n, t = 8192, 8000, 32768, 192
    wk = pow(r1, (1 << 28) // k, p)
    wn = pow(r2, (1 << 28) // n, p)
    assert r1 * r2 % p == 1
    assert pow(r1, 1 << 28, p) == 1 and pow(r1, 1 << 27, p) != 1
    assert pow(r2, 1 << 28, p) == 1 and pow(r2, 1 << 27, p) != 1
    assert pow(wn, 4, p) * wk % p == 1
    indices = [(-4 * i) % n for i in range(ell)]
    assert len(set(indices)) == ell
    assert all(pow(wk, i, p) == pow(wn, j, p) for i, j in enumerate(indices))
    return dict(field=p, k=k, ell=ell, n=n, t=t, root1_times_root2=1,
                message_points_in_code_domain=len(indices),
                mapping='j = (-4*i) mod n', first_eight_indices=indices[:8],
                expected_message_point_hits_if_192_distinct_uniform_queries=t * ell / n,
                scope='Exact pinned-constant calculation; not measured query outcomes or GPU execution.')


def mask_calculation():
    p, k, ell, n, t = 97, 4, 2, 16, 1
    generator, delta = 5, 5
    omega_k = pow(generator, (p - 1) // k, p)
    omega_n = pow(generator, (p - 1) // n, p)
    nodes = [pow(omega_k, i, p) for i in range(k)]
    domain = [delta * pow(omega_n, i, p) % p for i in range(n)]
    assert len(set(nodes)) == k and len(set(domain)) == n
    assert not set(nodes).intersection(domain)
    assert pow(delta, n, p) != 1 and k > ell + t
    point = domain[1]
    weights = []
    for i, node in enumerate(nodes):
        value = 1
        for j, other in enumerate(nodes):
            if i != j:
                value = value * (point - other) * pow((node - other) % p, -1, p) % p
        weights.append(value)

    def evaluate(row):
        return sum(a * b for a, b in zip(weights, row)) % p

    r, rho, sigma = 7, [5, 9], [2, 6]
    results = []
    for bit in [0, 1]:
        row = [bit, 0] + rho
        mask = sigma + [0, 0]
        decoded_response = [(r * x + y) % p for x, y in zip(row, mask)]
        sample = evaluate(row)
        statistic = (r * sample - evaluate([0, 0] + decoded_response[ell:])) % p
        recovered = statistic * pow(r * weights[0] % p, -1, p) % p
        assert recovered == bit
        counts = {i: 0 for i in range(p)}
        for a in range(p):
            for b in range(p):
                c = [(r * x + y) % p for x, y in zip(row, sigma + [a, b])]
                z = (r * sample - evaluate([0, 0] + c[ell:])) % p
                counts[z] += 1
        assert set(counts.values()) == {p}
        results.append(dict(bit=bit, opened_sample=sample,
                            response_decoded=decoded_response,
                            zero_tail_statistic=statistic, recovered_bit=recovered,
                            full_tail_mask_statistic_support=len(counts),
                            full_tail_mask_count_per_value=p))
    return dict(field=p, k=k, ell=ell, n=n, t=t,
                message_nodes=nodes, coset_delta=delta, code_domain=domain,
                disjoint=True, strict_padding_inequality=True,
                query_point=point, lagrange_weights=weights,
                public_row_weight=r, cases=results,
                scope='One linear code-test view with chosen fixed public weight; full-tail check concerns this statistic only. No commitment, full joint-view simulation, extraction or Fiat-Shamir attack is established.')


if __name__ == '__main__':
    print(json.dumps(dict(status='finite algebra calculations completed',
                          domain=domain_calculation(), mask=mask_calculation()), indent=2))
