# Next Codex task: one wrapper repair milestone

Use this package as a **candidate construction**, not an adopted proof profile.
Read README.md, algebra_model.py, results.json and source-map.json. Only manuscript
Sections II–VIII and agreed clarifications remain authoritative.

Preserve the completed KYC baseline, all datasets and the unresolved outcome of
CV-ONLINE-SAME-OBJECT-1. The attached model is new independent GF(4) evidence,
not native Binius correspondence or PQ-DID performance.

Implement an isolated small three-opening construction that extends the encrypted
wrapper through the inner algebraic opening verifier. Preserve two different
IntMul-style claims against the same Y and a separate trace claim. Use original
oracle randomisation, independent companion masks and fixed encrypted message
slots. One committed pad must bind the entire decrypted verifier transcript.
Do not leave terminal/companion/reduced claims on a plaintext bypass.

Use a separately complete outer ZK circuit-evaluation scheme, with an explicit
mapping to its construction. Do not assume the existing IronSpartan wrapper is
VEIL, wrap the same unfinished verifier recursively, or replace a missing proof
with synthetic acceptance. The source map in README.md identifies the affected
native boundaries. Reuse existing encoding, field, reduction and application code
where its semantics match.

First resolve the exact dependencies, message classification and outer-scheme
mapping in the same implementation package. A substantive failure of those
premises is a construction stop, not something passing component tests can waive.
The native attempt must include the complete small opening protocol and genuine
independent proof verification; it must not be labelled full authentication.

Deliver code, affected positive/negative regressions, individual outcomes, one
disclosure map and measured peak memory/time/message size. Include rejection of
changed targets, swapped slots, substituted Y/trace commitments, wrong context,
modified authenticated leaves, malformed encodings and invalid query budgets.
Map the IOP privacy argument separately from same-object extraction, round-by-round
knowledge and the exact salted Fiat–Shamir/compiler assumptions. Do not claim
overall post-quantum security from VEIL soundness or ML-DSA parameters.

Use the live repository's current authorisations. Before a blocked execution,
prepare the concrete patch and one consolidated prospective amendment covering
required builds, tests, proof attempts, time, memory, storage and completion.
Do not repurpose remaining corrective slots or reset historical consumption.
The current proof pause remains until explicitly amended. This file itself is
not an approval to increase limits or launch proofs.

Within an authorised milestone, complete routine corrections continuously and
reuse unaffected evidence. Stop only for an actual integrity/resource failure,
substantive construction barrier or action outside scope. Avoid another general
backend survey or review-only chain.

The result must be either a verified small native construction with precise
security limitations, or one concrete failed premise/counterexample/resource
barrier. Only after success should the unchanged complete authentication relation
and its unrun full-relation checks be integrated. Do not promise October completion
or convert baseline results into private-proof measurements.
