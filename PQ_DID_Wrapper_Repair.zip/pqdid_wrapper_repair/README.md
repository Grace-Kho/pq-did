# PQ-DID wrapper repair candidate

Date: 1 October 2026. This is a construction and executable algebra package for
the blocked private-proof work. It is **not a native patch or a private proof**.
The live WSL repository, resource ledgers and baseline have not been changed.

## Decision

Test a **wrapper that includes the algebraic opening verifier**, instead of
continuing the proposed hidden-terminal-slot/joint-opening construction.

Keep the complete authentication relation, application services, local reference
evaluators and genuine ML-DSA baseline. The protocol change concerns the private
proof layer. The old `CV-ONLINE-SAME-OBJECT-1` outcome remains unresolved for its
original construction; this candidate does not retroactively prove it.

The practical change is to hide every witness-dependent arithmetic message
through the end of the inner polynomial-opening protocol, and check its
decrypted value in one committed outer verification circuit. The two IntMul
claims and trace claim remain ordinary inner opening checks. They no longer
require the proposed cross-commitment hidden-slot equations.

Three changes must be made together:

1. Randomise the original encoded oracle, using the reviewed even/odd embedding
   and its decoder. A companion mask alone leaves original queried symbols exposed.
2. Move all sensitive claims and opening messages into the encrypted arithmetic
   transcript, and extend the outer circuit through those opening checks.
3. Use a suitable complete ZK circuit-evaluation layer and an appropriate salted
   IOP-to-argument compilation. Neither the existing outer implementation nor a
   salted hash alone is assumed to provide these properties.

This targets the demonstrated construction obstruction. Complete native
correspondence, knowledge extraction, finite parameters and full-authentication
resource admission are still required. October delivery is not guaranteed.

## What this package establishes

`algebra_model.py` implements a small, independent finite model; `results.json`
contains its actual results. All 12 cases passed. In particular:

- 786,432 complete randomness states were enumerated for fixed queries, covering
  all 16 two-symbol logical payloads, six query pairs and two admissible challenges.
- 65,536 states were enumerated for an adaptive-query rule using only the allowed
  view. Fifteen witness-distribution comparisons passed.
- Decoder identities and equal-fibre query distributions passed exhaustive checks.
- Negative controls demonstrate leakage without original-oracle randomisation,
  after exceeding the mask dimension, at a zero masking challenge, and when
  individual companion claims remain exposed alongside the stronger view.
- Fixed-object arithmetic checks reject altered claim targets and distinguish
  swapped slots or a substituted second IntMul object. These are not PCS checks.

The run took 2.683 seconds in this workspace. Linux process peak RSS was 14,976
KiB. This is not WSL benchmark evidence or a charged-cgroup measurement.
The model uses GF(4), a monomial evaluation map and **rate one**. It establishes
neither code distance nor cryptographic security, and is not the previously
validated native-field embedding implementation.

Reproduce into a fresh output path:

```sh
python3 -I -B algebra_model.py --output /tmp/pqdid-wrapper-model-new-results.json
```

The script refuses to overwrite an existing result. There are no third-party
dependencies, network requests, proof generation or authentication endpoints.

## 1. Why the existing wrapper boundary is insufficient

The retained pinned source at commit
`441fbf51ff0bcb0bcd28f3f1b73f4954029e8577` has two relevant properties:

- `ZKWrappedProverChannel::prove_oracle_relation` sends the claim through the
  underlying channel. Encrypting ordinary `send_one` calls does not hide it.
- `ZKWrappedProverChannel::finish` runs the outer proof before
  `inner_channel.finish()`. The combined BaseFold opening therefore occurs after
  the current wrapper witness has been fixed.

The retained BaseFold path also sends companion claims, sumcheck coefficients
and reduced evaluation claims. Hiding only the original terminal scalar is
insufficient. These extra values can correlate with the original witness.

Merely changing a host-side handle or asserting that two slots are equal does
not prove anything about the actual committed objects. This candidate instead
places the complete existing arithmetic opening checks inside the wrapper.

## 2. A limited shielded-view lemma

This section is an explicit algebraic argument for the proposed message boundary.
It does not simulate Merkle roots, Fiat–Shamir queries or the outer proof.

Let F be a finite field. For each oracle i, fix a logical payload a_i, linear
embedding maps J_i and B_i, decoder D_i, and linear code E_i. Require

\[
D_iJ_i=I,\qquad D_iB_i=0.
\]

Choose independently uniform embedding randomness rho_i and an independently
uniform full-length companion Omega_i. Define

\[
P_i=J_i a_i+B_i\rho_i,\qquad
V_i=(1-\gamma)P_i+\gamma\Omega_i,
\quad\gamma\ne0.
\]

All logical payloads may be correlated with each other. For this lemma, they
must be independent of these embedding/companion coins. Fix the honest
verifier's public-coin tape; it is independent of the prover randomness.

For every permitted set Q_i of distinct original-codeword positions, let L_i
be restriction of E_i to Q_i. Require L_i B_i to have full row rank. Count all
positions disclosed by a leaf/coset, not only the number of requested leaves.

**Claim.** The joint distribution of

\[
\bigl(V_i,\ L_iP_i,\ L_i\Omega_i\bigr)_i
\]

is independent of the logical payload tuple. Public-coin linear folds of the
V_i may also be revealed without changing that conclusion.

**Proof.** For every fixed P_i, the affine bijection from Omega_i to V_i makes
V_i uniform over its full vector space. Thus V_i is independent of P_i. By the
rank assumption, L_iP_i is uniform over its full output space, independently
of a_i and V_i. Linearity gives

\[
L_i\Omega_i=\gamma^{-1}
\bigl(L_iV_i-(1-\gamma)L_iP_i\bigr).
\]

The final component is therefore determined by the first two, whose joint
distribution is witness independent. Independent coins give the corresponding
joint statement for correlated logical payloads. The argument also covers
queries selected from prior permitted answers and V_i, provided the rank
condition holds for every resulting set. Cache repeated positions. This follows
by conditioning successively on previous answers: each new independent row has
equal-size fibres. It does not cover selection based on an additional hidden
prefix or an unmodelled witness-dependent message. QED.

For the reviewed native embedding, random even coordinates become a uniform
polynomial of degree below m after the encoder's bit reversal. Evaluation at
any q <= m distinct field points is surjective by interpolation. The retained
embedding report supplies the native basis/decoder correspondence; this package
does not rerun or extend its native validation.

**The important difference from the earlier attempt:** this is an unconditional
shielded marginal. We do not condition it on plaintext individual targets,
companion claims or outer multiplication messages. Those messages are removed
from this view and encrypted in the revised protocol. Their eventual consistency
must be proved by the separate outer layer.

At gamma=0 this lemma fails. At gamma=1 the view is private but the blend loses
the original relation. A candidate may abort on either value before revealing
dependent data; an actual profile must specify this branch, sampling and its
effect on completeness and soundness. No rejection-sampling policy or error
budget has been adopted here.

## 3. Proposed native transcript boundary

Use a fixed public layout and typed message schedule. No witness-dependent
message counts, oracle sizes or host control flow may bypass it.

| Data | Proposed treatment |
|---|---|
| Statement, suite, circuit/layout identity, audience/challenge/state context | Public and transcript bound |
| Trace and IntMul logical data | Private, encoded with fresh embedding randomness |
| Both IntMul targets and trace target | Separate encrypted scalar slots |
| Companion claims, opening sumcheck coefficients, reduced evaluations and any unclassified witness-dependent scalar | Encrypted slots |
| Queried original/companion symbols | Shielded only under the full query-rank budget |
| Folded codeword data | Shielded only after proving it is a function of blended vectors and public coins |
| Merkle roots, paths and optimal layers | Separate compiler simulation obligation |
| Outer proof messages | Governed by the selected complete outer ZK construction |

The public verifier authenticates the shielded leaf bytes. Those **exact values**
must become the outer circuit's public inputs; accepting separate unauthenticated
copies would break the construction. The leaf order, oracle identity, code domain,
indices, field encoding and context must be fixed and bound as well.

Keep both IntMul openings attached to the same Y object. The equality operand
uses the returned `pushforward_eval_point`, obtained from the **last**
`table.n_vars` coordinates of `node_point` in `verify_reduction_transparent`.
Do not substitute a generic table-prefix rule. The power-table opening follows;
the trace equation retains its own existing position.

The retained `prove_mlecheck_basefold` passes the masking challenge into FRI
before the ordinary folding rounds. The combined witness and lifts inspected
here are linear functions of the blended vectors. This is useful source evidence,
but it is not an exhaustive audit of every native FRI disclosure or parameter.

## 4. Wrapper contract and why it changes the old problem

The construction reference is VEIL, definitions 4.1–4.2, lemma 4.3 and figure 7
[1]. Its compiler commits to an independent pad vector h, transmits c=v+h for
the exposed arithmetic transcript v, and proves C_(s,x,r)(c-h)=0 using a ZK
commit-and-prove circuit-evaluation scheme. Its section 3.3 supplies a proposed
outer scheme; the existing IronSpartan wrapper is not automatically that scheme.
The stated result concerns ZK and soundness in the IOP model, not an automatic
knowledge or concrete-hash guarantee.

For this application, C must include the inner verifier **and its algebraic
opening verifier**. One committed h fixes one decrypted transcript. The two
ordinary Y opening equations and trace equation are checked against the same
authenticated inner objects within C. There is no additional separately
committed claim-slot witness to reconcile in a new joint-opening protocol.

Execution architecture:

1. Fix the full public message layout and bind the statement/context. Commit
   the outer pad once using the selected outer scheme.
2. Run the inner relation reductions and complete inner opening protocol,
   collecting encrypted arithmetic messages and authenticated shielded inputs.
3. Construct/replay the complete arithmetic acceptance predicate on those inputs.
4. Run the separate outer circuit-evaluation protocol. Its own openings belong
   to that complete protocol; do not feed them recursively into this wrapper.
5. Verify the compiler transcript, authenticated data and outer result before
   returning private authentication success.

This is **not** achieved by moving one `finish()` line. The present combined
inner/outer opening channel needs separation, and the symbolic verifier must
record all affected checks. Do not replace any missing check with a test adapter.

In particular, fixed-coin IOP simulation does not mean we have constructed the
old online simulator for already-fixed concrete hash roots. The proof strategy
changes: establish the complete IOP properties first, then apply a matching
IOP-to-argument compiler. Keeping the old simulator game unchanged would leave
the original gap unchanged too.

## 5. Merkle and post-quantum composition

Diamond's discussion of the zero-knowledge BCS transform [2, section 4.1]
requires fresh secret salt in leaf/tag hashing. This addresses the unsalted-root
problem; it does not prove that a witness-dependent queried symbol is hidden.
Salts and algebraic masks have different roles. The simulator's oracle state
is part of the security model. A concrete SHA implementation is not thereby
proved programmable or quantum secure.

Chiesa–Manohar–Spooner [3, theorem 8.6] gives a QROM route for BCS based on
honest-verifier ZK and round-by-round soundness/knowledge of the underlying IOP.
Their section 8.6 distinguishes hash-chain variants. Applicability requires
matching the exact protocol and compiler; ordinary soundness is insufficient
for their knowledge conclusion.

For the revised PQ-DID construction, the remaining security work is therefore
specific:

- Demonstrate that **every** shielded native message is covered by a joint
  witness-free distribution argument, with actual dimensions and query counts.
- Instantiate the outer scheme and show that its commitment binds one pad h
  throughout the transcript; include its auxiliary masks and query views.
- Give an efficient extraction path for the decoded inner trace and all oracle
  relations from the same committed transcript. Establish round-by-round
  knowledge for the composition, rather than citing the soundness compiler as
  if it proved extraction.
- Match salted commitments, all message ordering and the Fiat–Shamir chain to
  the selected theorem. Include context binding and exceptional challenges.
- Select finite field/hash/salt/query parameters with explicit reduction-query
  budgets. ML-DSA-65 does not assign an overall security level to this proof.
- Carry forward the existing bounded-signing/adaptive-tail qualifications and
  the difference between ideal hash assumptions and concrete instantiation.

This package does not supply that complete extraction/parameter argument. It
replaces an unproved bespoke bridge with explicit compiler premises and a
proved, narrower algebraic distribution claim.

### A precise conditional knowledge-composition target

The extraction requirement can be reduced further than “prove composition”.
The following is a conditional lemma for an ideal-oracle protocol. Its premises
have **not** been established for the retained implementation.

Assume (a) an efficient fixed decoder d(H) for the outer pad commitment oracle H;
(b) round-by-round knowledge for the base IOP, with error k0 and an extractor
consistent with one common committed relation witness and its inner objects;
(c) round-by-round
binding soundness of the outer evaluation protocol relative to d(H), with error
epsilon_c, even when its circuit is chosen after H; and (d) an efficient exact
prefix translation using v=c-d(H). Require the base public-coin schedule to be
well-defined without revealing v outside that translation.

Then the wrapped IOP inherits a round-by-round knowledge target of
max(k0, epsilon_c) under those ideal premises. This is a symbolic conditional
bound, not an evaluated parameter or an application to the native implementation.

To see why, before the base IOP finishes, use its state function on the translated
prefix. A verifier move with a transition probability exceeding k0 admits the
base extractor on that prefix, using the same fixed d(H). At base completion,
if that state is zero then the exact base acceptance predicate is false, so
C(c-d(H)) is nonzero. For this branch use the outer protocol's false-evaluation
state function; a transition above epsilon_c is excluded by premise (c). If the
base terminal state was one, keep state one through the outer suffix. Prover
moves cannot change a zero state to one in either branch; a completed accepted
transcript has state one. The only transitions requiring a witness extractor
are therefore the base transitions, whose translated oracle objects are fixed.

This argument supplies a composition strategy, not the missing premises. A
nonconstructive assertion that a commitment “binds some h” does not provide (a).
Ordinary soundness for a fixed circuit does not provide (c). An approximate
decoder, bad commitments, exceptional challenges or a changed challenge
distribution require their own analysis; their errors cannot simply be omitted.
The proposed native milestone should determine whether the selected outer
construction supplies this stronger decoder/binding interface. No extractor is
implemented in the accompanying finite model.

## 6. Concrete source change map

| Retained source/function | Required change or reusable function |
|---|---|
| `iop-prover/fri/encode.rs::encode_masked` | Apply the reviewed original-oracle embedding before independent companion generation; retain the decoder and exact domain mapping |
| `spartan-prover/wrapper/zk_wrapped_prover_channel.rs::prove_oracle_relation` | Remove the plaintext-claim bypass in the experimental route; use a fixed encrypted slot |
| Matching verifier `verify_oracle_relation` | Recover the symbolic private claim from the same committed pad and retain the actual opening equation |
| Wrapper `finish` and BaseFold `finish` | Separate inner completion from the complete outer proof; capture opening messages before fixing C |
| `iop-prover/basefold/channel.rs::prove_batch_zk_basefold` | Classify/encrypt companion claims, phase-A messages and reduced evaluations; preserve batching equations |
| `iop-prover/basefold/opening.rs::prove_mlecheck_basefold` and verifier counterpart | Record the phase-B algebraic checks in C and authenticate the identical shielded leaves |
| `logup_star` transparent prover/verifier and reduction | Reuse same-Y operands and returned suffix point; do not add an unrelated copy of Y |
| Merkle/transcript compiler | Implement the selected salted compiler exactly in a new versioned profile |
| Outer R1CS evaluator | Implement or demonstrate correspondence to a complete ZK scheme; no recursive placeholder |

`source-map.json` records hashes of the local material used. It is a research
provenance map, not a native dependency lock or a new preservation baseline.

## 7. One implementation milestone, with a decisive result

The next useful deliverable is a **small native three-opening construction**:
one shared Y with two different operands, one trace opening, the complete
encrypted algebraic opening transcript, and a real selected outer proof.
Use a synthetic relation small enough for exact independent checks. It is not
complete authentication, but it must exercise the actual compiler boundary.

Complete the source edits, affected regressions and routine corrections as one
package. Do not add another backend survey or a succession of documentation-only
reviews. The package must return one of:

- A genuine independently verified small proof, message/disclosure accounting,
  measured memory/time/size and a mapped security argument with precise remaining
  assumptions; or
- A concrete counterexample, failed theorem premise, missing essential native
  dependency, or measured resource barrier that prevents that construction.

Before executing in WSL, use its **actual** prerequisites and limits. The seven
reported unused corrective test slots are not a general execution allowance.
The current proof pause/ledger must not be bypassed by calling a proof a test.
If an amendment is needed, make one prospective request for this whole milestone,
with enough space and time for routine corrections and finalisation. No budget
amendment is made by this package.

After that small construction succeeds, integrate the unchanged complete PQ-DAA
relation and resolve the previously unrun full-relation checks. Preserve bounded
ML-DSA verification, exact Mcred, same holder opening, policy/disclosure and
non-revocation for the same certified identifier. Require independent relation
comparisons before full proving. Measure simultaneous codeword, matrix, witness,
Merkle, padding, salt and outer-proof memory; component counts are insufficient.

## 8. Manuscript and delivery consequences

- Sections IV–VI may retain the generic scheme only where their assumptions and
  interfaces still match this replacement. Do not weaken the relation to fit it.
- Section VII must describe the adopted proof profile and exact transcript once
  validated. The old BC-1 implementation cannot describe this compiler.
- Section VIII must separate the new IOP/compiler arguments, knowledge conditions,
  QROM model, concrete parameters and unresolved signing/hash terms.
- Section II may need the new proof references; III may need definitions. Sections
  outside II–VIII remain deferred as the user instructed.
- The genuine baseline, 302 historical observations and four smoke observations
  remain their own evidence. They cannot become private-proof measurements.

No present result guarantees a full private implementation by 31 October 2026.
The route preserves the completed KYC/application work and gives one narrow
native decision point before another large full-authentication investment.

## References and evidence scope

1. Dalal, Hemo, Rabinovich and Rothblum, *VEIL: Lightweight Zero-Knowledge for
   Hash-Based Multilinear Proof Systems*, ePrint 2026/683.
   https://eprint.iacr.org/2026/683.pdf
2. Diamond, *Zero-Knowledge Polynomial Commitment in Binary Fields*, ePrint 2025/1015.
   https://eprint.iacr.org/2025/1015.pdf
3. Chiesa, Manohar and Spooner, *Succinct Arguments in the Quantum Random Oracle
   Model*, ePrint 2019/834, especially definitions 8.3–8.5 and theorem 8.6.
   https://eprint.iacr.org/2019/834.pdf

Titles/identifiers and theorem locations were checked against primary sources.
The argument in section 2 and its finite model are this package's analysis, with
the explicitly stated premises. This is not an independent audit of those papers.
No production source, old report, baseline measurement or WSL ledger was modified.
