#!/usr/bin/env python3
"""Finite algebra model for a proposed PQ-DID proof-wrapper repair.

NOT a proof system, native Binius port, authentication verifier or security test.
GF(4), a length-four rate-one evaluation map, ideal fixed objects, public coins.
The model checks exact distributions and deliberately failing assumptions.
Run: python3 -I -B algebra_model.py --output /fresh/path/results.json
"""

from __future__ import annotations

import argparse
from collections import Counter
from itertools import combinations, product
import json
from pathlib import Path
import platform
import resource
import sys
import time


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def multiply_slow(a: int, b: int) -> int:
    """Polynomial multiplication modulo X^2+X+1, independent of tables."""
    value = 0
    for bit in range(2):
        if (b >> bit) & 1:
            value ^= a << bit
    if value & 4:
        value ^= 7
    return value


MUL = tuple(tuple(multiply_slow(a, b) for b in range(4)) for a in range(4))
INV = (None, 1, 3, 2)
VECTORS = tuple(product(range(4), repeat=4))
PAYLOADS = tuple(product(range(4), repeat=2))
QUERY_PAIRS = tuple(combinations(range(4), 2))


def evaluate(physical: tuple[int, ...], point: int) -> int:
    """Toy monomial basis with two-bit reversal: coefficients p0,p2,p1,p3.

    This is not the native Gao-Mateer basis. Random coordinates span degree<2,
    as required by the abstract rank argument. No native correspondence claimed.
    """
    coefficients = (physical[0], physical[2], physical[1], physical[3])
    result = 0
    for coefficient in reversed(coefficients):
        result = MUL[result][point] ^ coefficient
    return result


CODES = {vector: tuple(evaluate(vector, x) for x in range(4)) for vector in VECTORS}


def embed(payload: tuple[int, int], rho: tuple[int, int]) -> tuple[int, ...]:
    return (rho[0], payload[0], rho[1], payload[1])


def blend(p: tuple[int, ...], omega: tuple[int, ...], gamma: int) -> tuple[int, ...]:
    return tuple(MUL[1 ^ gamma][a] ^ MUL[gamma][b] for a, b in zip(p, omega))


def dot(a: tuple[int, ...], b: tuple[int, ...]) -> int:
    require(len(a) == len(b), "dot-product shape")
    out = 0
    for x, y in zip(a, b):
        out ^= MUL[x][y]
    return out


def distribution(payload, gamma, query_rule):
    """Exact multiplicities, exposing whole V as a deliberately stronger view."""
    counts = Counter()
    for rho in PAYLOADS:
        p = embed(payload, rho)
        ep = CODES[p]
        for omega in VECTORS:
            v = blend(p, omega, gamma)
            query = query_rule(v, ep)
            answers_p = tuple(ep[x] for x in query)
            answers_omega = tuple(CODES[omega][x] for x in query)
            if gamma:
                inverse = INV[gamma]
                derived = tuple(
                    MUL[inverse][CODES[v][x] ^ MUL[1 ^ gamma][ep[x]]]
                    for x in query
                )
                require(derived == answers_omega, "paired opening formula")
            counts[(v, query, answers_p, answers_omega)] += 1
    return counts


def field_and_encoding():
    for a, b, c in product(range(4), repeat=3):
        require(MUL[a][b] == MUL[b][a], "commutativity")
        require(MUL[MUL[a][b]][c] == MUL[a][MUL[b][c]], "associativity")
        require(MUL[a][b ^ c] == (MUL[a][b] ^ MUL[a][c]), "distributivity")
    for a in range(1, 4):
        require(MUL[a][INV[a]] == 1, "inverse")
    require(len(set(CODES.values())) == 256, "evaluation bijection")
    return {"field": "GF(4), X^2+X+1", "encoding_rate": 1, "vectors": 256}


def decoder_identity():
    checks = 0
    for p in VECTORS:
        for t in PAYLOADS:
            require(dot(p, (0, t[0], 0, t[1])) == dot((p[1], p[3]), t), "decoder")
            checks += 1
    return {"exhaustive_identities": checks}


def original_query_rank():
    checks = 0
    for q in (1, 2):
        for indices in combinations(range(4), q):
            for payload in PAYLOADS:
                images = Counter(
                    tuple(CODES[embed(payload, rho)][x] for x in indices) for rho in PAYLOADS
                )
                require(len(images) == 4**q, "full image")
                require(set(images.values()) == {4 ** (2 - q)}, "equal fibres")
                checks += 1
    return {"query_set_payload_combinations": checks, "maximum_distinct_positions": 2}


def exhaustive_fixed_queries():
    states = 0
    comparisons = 0
    for gamma in (2, 3):
        for indices in QUERY_PAIRS:
            first = None
            for payload in PAYLOADS:
                counts = distribution(payload, gamma, lambda v, ep: indices)
                require(len(counts) == 4096, "expected complete support")
                require(set(counts.values()) == {1}, "uniform joint view")
                if first is None:
                    first = counts
                else:
                    require(counts == first, "payload-dependent shielded view")
                    comparisons += 1
                states += 4096
    return {"enumerated_states": states, "distribution_comparisons": comparisons}


def adaptive_queries():
    # First point is 0. The second is selected from V and the first answer.
    # This excludes dependence on roots, hash queries or unencrypted exposed data.
    def rule(v, ep):
        return (0, 1 + ((v[0] ^ ep[0]) % 3))

    first = distribution((0, 0), 2, rule)
    for payload in PAYLOADS[1:]:
        require(distribution(payload, 2, rule) == first, "adaptive distribution mismatch")
    return {"enumerated_states": 16 * 4096, "distribution_comparisons": 15}


def query_budget_negative_control():
    indices = (0, 1, 2)
    left = {tuple(CODES[embed((0, 0), r)][i] for i in indices) for r in PAYLOADS}
    right = {tuple(CODES[embed((1, 0), r)][i] for i in indices) for r in PAYLOADS}
    require(left.isdisjoint(right), "rank-exhaustion counterexample missing")
    return {"query_count": 3, "mask_dimension": 2, "disjoint_supports": True}


def missing_randomness_negative_control():
    # Unmodified raw messages reveal their first coordinate at evaluation zero.
    require(evaluate((0, 1, 2, 3), 0) == 0, "raw zero coordinate")
    require(evaluate((1, 1, 2, 3), 0) == 1, "raw zero coordinate")
    return {"raw_first_coordinate_is_exposed": True}


def gamma_zero_negative_control():
    query = lambda v, ep: (0, 1)
    left = distribution((0, 0), 0, query)
    right = distribution((1, 0), 0, query)
    require(set(left).isdisjoint(right), "gamma-zero leakage missing")
    return {"whole_view_supports_disjoint": True}


def gamma_one_negative_control():
    p1 = (0, 0, 0, 0)
    p2 = (0, 1, 0, 0)
    omega = (1, 2, 3, 0)
    require(blend(p1, omega, 1) == blend(p2, omega, 1), "gamma-one independence")
    operand = (0, 1, 0, 0)
    require(dot(p1, operand) != dot(p2, operand), "different original claims")
    return {"original_relation_not_determined_by_blend": True}


def exposed_claim_negative_control():
    # Individual companion claims plus V reveal individual original targets.
    gamma = 2
    operand = (0, 1, 0, 0)
    recovered = set()
    for rho in PAYLOADS:
        p = embed((3, 2), rho)
        for omega in VECTORS:
            v = blend(p, omega, gamma)
            sigma = dot(omega, operand)
            value = MUL[INV[1 ^ gamma]][dot(v, operand) ^ MUL[gamma][sigma]]
            recovered.add(value)
    require(recovered == {3}, "target recovery")
    return {"recovered_first_logical_symbol": 3, "states": 4096}


def ciphertext_uniformity():
    # Exact three-message OTP marginal, including perfectly correlated plaintexts.
    pads = tuple(product(range(4), repeat=3))
    reference = None
    for a, b in PAYLOADS:
        plaintext = (a, b, MUL[a][b])
        ciphertexts = Counter(tuple(x ^ h for x, h in zip(plaintext, pad)) for pad in pads)
        require(set(ciphertexts.values()) == {1}, "ciphertext uniformity")
        if reference is None:
            reference = ciphertexts
        else:
            require(ciphertexts == reference, "plaintext-dependent ciphertext marginal")
    # Reusing a pad instead leaves the plaintext difference public.
    require({(1 ^ h) ^ (2 ^ h) for h in range(4)} == {3}, "pad-reuse control")
    return {"plaintexts": 16, "pads_each": 64, "pad_reuse_leaks_difference": True}


def same_object_equations():
    # Exact fixed-object arithmetic only. There is no PCS or succinct proof here.
    objects = {"Y": (1, 2), "PI": (3, 1)}
    schedule = (("Y", (1, 0)), ("Y", (0, 1)), ("PI", (1, 1)))
    plaintext = tuple(dot(objects[name], operand) for name, operand in schedule)
    checks = 0
    for pad in product(range(4), repeat=3):
        ciphertext = tuple(v ^ h for v, h in zip(plaintext, pad))
        recovered = tuple(c ^ h for c, h in zip(ciphertext, pad))
        require(recovered == plaintext, "same committed pad must decrypt all slots")
        require(all(recovered[i] == dot(objects[name], t) for i, (name, t) in enumerate(schedule)), "same object equations")
        for slot in range(3):
            changed = list(ciphertext)
            changed[slot] ^= 1
            require((changed[slot] ^ pad[slot]) != plaintext[slot], "changed target rejection")
            checks += 1
    require(plaintext[0] != plaintext[1], "fixture must detect swapped Y slots")
    require(dot((1, 3), schedule[1][1]) != plaintext[1], "different Y object rejection")
    return {"tampered_targets_rejected": checks, "swapped_slots_differ": True, "scope": "ideal fixed-object arithmetic, not extraction"}


CASES = (
    ("A-01", field_and_encoding),
    ("A-02", decoder_identity),
    ("A-03", original_query_rank),
    ("A-04", exhaustive_fixed_queries),
    ("A-05", adaptive_queries),
    ("A-06", query_budget_negative_control),
    ("A-07", missing_randomness_negative_control),
    ("A-08", gamma_zero_negative_control),
    ("A-09", gamma_one_negative_control),
    ("A-10", exposed_claim_negative_control),
    ("A-11", ciphertext_uniformity),
    ("A-12", same_object_equations),
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("refusing to overwrite an existing result")
    started = time.perf_counter()
    outcomes = []
    for name, function in CASES:
        case_start = time.perf_counter()
        try:
            details = function()
            outcome = {"id": name, "name": function.__name__, "passed": True, "details": details}
        except Exception as exc:
            outcome = {"id": name, "name": function.__name__, "passed": False, "error": str(exc), "type": type(exc).__name__}
        outcome["wall_seconds"] = time.perf_counter() - case_start
        outcomes.append(outcome)
        if not outcome["passed"]:
            break
    result = {
        "scope": "finite algebra model only; no native comparison or private proof",
        "python": sys.version,
        "platform": platform.platform(),
        "cases": outcomes,
        "complete": len(outcomes) == len(CASES) and all(item["passed"] for item in outcomes),
        "wall_seconds": time.perf_counter() - started,
        "process_peak_rss_kib_linux": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "cgroup_memory_measurement": None,
        "production_modified": False,
        "cryptographic_proof_generated": False,
        "pq_security_established": False,
        "native_correspondence_established": False,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", encoding="utf-8") as file:
        json.dump(result, file, indent=2)
        file.write("\n")
    print(json.dumps({"complete": result["complete"], "cases": len(outcomes), "wall_seconds": result["wall_seconds"], "process_peak_rss_kib_linux": result["process_peak_rss_kib_linux"]}))
    return 0 if result["complete"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
